
package com.example.demo;

import javax.persistence.*;

@Entity
@Table(name = "fashion_data")
public class FashionData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String p_id;
    private String p_name;
    private String colour;
    private String brand;
    private String img;
    private int ratingcount;
    private double avg_rating;
    private String description;
    private double price;
    private String p_attributes;
    private int rating_count;

    // Getters and setters
    // ...
}
