
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fashion")
public class FashionDataController {

    @Autowired
    private FashionDataRepository repository;

    @GetMapping
    public List<FashionData> getAllFashionData() {
        return repository.findAll();
    }
}
